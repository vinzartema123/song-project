<div class="container-fluid">
  <div class="row">
    <div class="col-md-12">
      <div class="dashboard-content-container">
        <h1 class="display-4">Hello, <?= session()->get('firstname') ?> Try And Create Your Song Lyrics </h1>
        <br>
      
    </div>
  </div>
</div>